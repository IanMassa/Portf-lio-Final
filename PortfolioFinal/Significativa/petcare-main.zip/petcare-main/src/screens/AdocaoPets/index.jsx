import { View, Text } from 'react-native'
import React from 'react'

export default function AdocaoPets() {
  return (
    <View>
      <Text>AdocaoPets</Text>
    </View>
  )
}